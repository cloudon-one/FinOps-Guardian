"""Unit tests for main Cloud Function entry point."""

import pytest
from unittest.mock import patch, Mock, MagicMock
from main import check_recommender


@pytest.mark.unit
class TestMain:
    """Tests for main Cloud Function."""

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    def test_check_recommender_no_recommenders_enabled(
        self, mock_get_recommenders, mock_context
    ):
        """Test function handles case with no enabled recommenders."""
        mock_get_recommenders.return_value = []

        # Should not raise exception
        check_recommender(None, mock_context)

        assert mock_get_recommenders.called

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    def test_check_recommender_executes_recommenders(
        self, mock_get_recommenders, mock_context
    ):
        """Test function executes all enabled recommenders."""
        mock_rec1 = Mock()
        mock_rec1.__class__.__name__ = "VMIdleResourceRecommender"
        mock_rec2 = Mock()
        mock_rec2.__class__.__name__ = "CloudSQLIdleResourceRecommender"

        mock_get_recommenders.return_value = [mock_rec1, mock_rec2]

        check_recommender(None, mock_context)

        assert mock_rec1.detect.called
        assert mock_rec2.detect.called

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    def test_check_recommender_continues_on_error(
        self, mock_get_recommenders, mock_context
    ):
        """Test function continues executing even if one recommender fails."""
        mock_rec1 = Mock()
        mock_rec1.__class__.__name__ = "VMIdleResourceRecommender"
        mock_rec1.detect.side_effect = Exception("Test error")

        mock_rec2 = Mock()
        mock_rec2.__class__.__name__ = "CloudSQLIdleResourceRecommender"

        mock_get_recommenders.return_value = [mock_rec1, mock_rec2]

        # Should not raise exception
        check_recommender(None, mock_context)

        # Both should be called even though first one failed
        assert mock_rec1.detect.called
        assert mock_rec2.detect.called

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    def test_check_recommender_logs_execution(
        self, mock_get_recommenders, mock_context
    ):
        """Test function logs execution details."""
        mock_rec = Mock()
        mock_rec.__class__.__name__ = "VMIdleResourceRecommender"
        mock_get_recommenders.return_value = [mock_rec]

        with patch("main.logger") as mock_logger:
            check_recommender(None, mock_context)

            # Should log start and completion
            assert mock_logger.info.called
            assert mock_logger.info.call_count >= 2

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    def test_check_recommender_critical_error(
        self, mock_get_recommenders, mock_context
    ):
        """Test function handles critical errors appropriately."""
        mock_get_recommenders.side_effect = Exception("Critical error")

        with pytest.raises(Exception) as exc_info:
            check_recommender(None, mock_context)

        assert "Critical error" in str(exc_info.value)


@pytest.mark.integration
class TestMainIntegration:
    """Integration tests for main function."""

    @patch("main.RecommenderFactory.get_enabled_recommenders")
    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_full_execution_with_mocked_apis(
        self,
        mock_recommender_client,
        mock_asset_client,
        mock_get_recommenders,
        mock_context,
        monkeypatch
    ):
        """Test full execution flow with mocked GCP APIs."""
        from localpackage.recommender.compute.idle_resource import VMIdleResourceRecommender

        monkeypatch.setenv("IDLE_VM_RECOMMENDER_ENABLED", "true")

        # Create a real recommender instance
        recommender = VMIdleResourceRecommender()

        # Mock the API responses
        mock_asset_response = Mock()
        mock_asset_response.results = []
        mock_asset_response.next_page_token = ""
        recommender.asset_client.search_all_resources = Mock(
            return_value=mock_asset_response
        )

        mock_get_recommenders.return_value = [recommender]

        # Should execute without errors
        check_recommender(None, mock_context)

        assert recommender.asset_client.search_all_resources.called
