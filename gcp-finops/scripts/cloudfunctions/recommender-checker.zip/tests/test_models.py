"""Unit tests for data models."""

import pytest
from localpackage.recommender.models import (
    ProjectInfo,
    CostImpact,
    RecommendationSummary,
    RecommenderConfig
)


@pytest.mark.unit
class TestProjectInfo:
    """Tests for ProjectInfo dataclass."""

    def test_project_info_creation(self):
        """Test ProjectInfo can be created with required fields."""
        project = ProjectInfo(number="123456", name="test-project")
        assert project.number == "123456"
        assert project.name == "test-project"


@pytest.mark.unit
class TestCostImpact:
    """Tests for CostImpact dataclass."""

    def test_cost_impact_creation(self):
        """Test CostImpact can be created with all fields."""
        cost = CostImpact(
            units=100,
            nanos=500000000,
            currency="USD",
            duration="30 days",
            total_cost=100.5
        )
        assert cost.units == 100
        assert cost.nanos == 500000000
        assert cost.currency == "USD"
        assert cost.duration == "30 days"
        assert cost.total_cost == 100.5


@pytest.mark.unit
class TestRecommendationSummary:
    """Tests for RecommendationSummary dataclass."""

    def test_recommendation_summary_creation(self):
        """Test RecommendationSummary can be created."""
        cost_impact = CostImpact(
            units=50,
            nanos=0,
            currency="USD",
            duration="30 days",
            total_cost=50.0
        )

        summary = RecommendationSummary(
            project_id="test-project",
            recommender_type="idle_vm",
            recommender_subtype="STOP_VM",
            description="Stop idle VM",
            cost_impact=cost_impact
        )

        assert summary.project_id == "test-project"
        assert summary.recommender_type == "idle_vm"
        assert summary.cost_impact.total_cost == 50.0

    def test_should_notify_above_threshold(self):
        """Test should_notify returns True when cost is above threshold."""
        cost_impact = CostImpact(
            units=100,
            nanos=0,
            currency="USD",
            duration="30 days",
            total_cost=100.0
        )

        summary = RecommendationSummary(
            project_id="test-project",
            recommender_type="idle_vm",
            recommender_subtype="STOP_VM",
            description="Stop idle VM",
            cost_impact=cost_impact
        )

        assert summary.should_notify(min_cost_threshold=50.0) is True

    def test_should_notify_below_threshold(self):
        """Test should_notify returns False when cost is below threshold."""
        cost_impact = CostImpact(
            units=10,
            nanos=0,
            currency="USD",
            duration="30 days",
            total_cost=10.0
        )

        summary = RecommendationSummary(
            project_id="test-project",
            recommender_type="idle_vm",
            recommender_subtype="STOP_VM",
            description="Stop idle VM",
            cost_impact=cost_impact
        )

        assert summary.should_notify(min_cost_threshold=50.0) is False


@pytest.mark.unit
class TestRecommenderConfig:
    """Tests for RecommenderConfig dataclass."""

    def test_recommender_config_minimal(self):
        """Test RecommenderConfig with minimal required fields."""
        config = RecommenderConfig(organization_id="123456")
        assert config.organization_id == "123456"
        assert config.slack_webhook_url is None
        assert config.min_cost_threshold == 0.0
        assert config.use_secret_manager is False

    def test_recommender_config_full(self):
        """Test RecommenderConfig with all fields."""
        config = RecommenderConfig(
            organization_id="123456",
            slack_webhook_url="https://hooks.slack.com/test",
            min_cost_threshold=100.0,
            use_secret_manager=True,
            secret_project_id="my-project",
            secret_name="slack-webhook"
        )

        assert config.organization_id == "123456"
        assert config.slack_webhook_url == "https://hooks.slack.com/test"
        assert config.min_cost_threshold == 100.0
        assert config.use_secret_manager is True
        assert config.secret_project_id == "my-project"
        assert config.secret_name == "slack-webhook"
