"""Unit tests for RecommenderFactory."""

import os
import pytest
from unittest.mock import patch, MagicMock
from localpackage.recommender.factory import RecommenderFactory
from localpackage.recommender.compute.idle_resource import VMIdleResourceRecommender


@pytest.mark.unit
class TestRecommenderFactory:
    """Tests for RecommenderFactory class."""

    def test_get_enabled_recommenders_none_enabled(self):
        """Test when no recommenders are enabled."""
        # All default to "false"
        recommenders = RecommenderFactory.get_enabled_recommenders()
        assert len(recommenders) == 0

    def test_get_enabled_recommenders_one_enabled(self, monkeypatch):
        """Test when one recommender is enabled."""
        monkeypatch.setenv("IDLE_VM_RECOMMENDER_ENABLED", "true")

        with patch("google.cloud.recommender_v1.RecommenderClient"):
            with patch("google.cloud.asset_v1.AssetServiceClient"):
                recommenders = RecommenderFactory.get_enabled_recommenders()
                assert len(recommenders) == 1
                assert isinstance(recommenders[0], VMIdleResourceRecommender)

    def test_get_enabled_recommenders_multiple_enabled(self, monkeypatch):
        """Test when multiple recommenders are enabled."""
        monkeypatch.setenv("IDLE_VM_RECOMMENDER_ENABLED", "true")
        monkeypatch.setenv("IDLE_DISK_RECOMMENDER_ENABLED", "true")
        monkeypatch.setenv("IDLE_SQL_RECOMMENDER_ENABLED", "true")

        with patch("google.cloud.recommender_v1.RecommenderClient"):
            with patch("google.cloud.asset_v1.AssetServiceClient"):
                recommenders = RecommenderFactory.get_enabled_recommenders()
                assert len(recommenders) == 3

    def test_get_enabled_recommenders_case_insensitive(self, monkeypatch):
        """Test that environment variable checking is case-insensitive."""
        monkeypatch.setenv("IDLE_VM_RECOMMENDER_ENABLED", "TRUE")
        monkeypatch.setenv("IDLE_DISK_RECOMMENDER_ENABLED", "True")

        with patch("google.cloud.recommender_v1.RecommenderClient"):
            with patch("google.cloud.asset_v1.AssetServiceClient"):
                recommenders = RecommenderFactory.get_enabled_recommenders()
                assert len(recommenders) == 2

    def test_list_available_recommenders(self):
        """Test listing all available recommender types."""
        available = RecommenderFactory.list_available_recommenders()
        assert "IDLE_VM_RECOMMENDER" in available
        assert "IDLE_SQL_RECOMMENDER" in available
        assert "MIG_RIGHTSIZE_RECOMMENDER" in available
        assert len(available) == 10  # Total number of registered recommenders

    def test_register_custom_recommender(self):
        """Test registering a custom recommender."""
        from localpackage.recommender.recommender import Recommender

        class CustomRecommender(Recommender):
            def __init__(self):
                super().__init__("custom.recommender", "custom.asset.type")

        initial_count = len(RecommenderFactory.list_available_recommenders())
        RecommenderFactory.register_recommender("CUSTOM_RECOMMENDER", CustomRecommender)
        new_count = len(RecommenderFactory.list_available_recommenders())

        assert new_count == initial_count + 1
        assert "CUSTOM_RECOMMENDER" in RecommenderFactory.list_available_recommenders()

    def test_get_enabled_recommenders_handles_instantiation_error(self, monkeypatch):
        """Test that factory handles errors during recommender instantiation."""
        monkeypatch.setenv("IDLE_VM_RECOMMENDER_ENABLED", "true")

        # Mock the recommender class to raise an exception
        with patch("localpackage.recommender.factory.VMIdleResourceRecommender") as mock_class:
            mock_class.side_effect = Exception("Test error")

            recommenders = RecommenderFactory.get_enabled_recommenders()
            # Should return empty list and log error instead of crashing
            assert len(recommenders) == 0
