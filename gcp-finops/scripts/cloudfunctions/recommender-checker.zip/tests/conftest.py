"""Pytest configuration and shared fixtures."""

import os
import pytest
from unittest.mock import Mock, MagicMock


@pytest.fixture(autouse=True)
def setup_env():
    """Set up environment variables for testing."""
    os.environ["ORGANIZATION_ID"] = "123456789"
    os.environ["SLACK_HOOK_URL"] = "https://hooks.slack.com/test"
    os.environ["MIN_COST_THRESHOLD"] = "0"
    os.environ["USE_SECRET_MANAGER"] = "false"
    yield
    # Cleanup
    for key in list(os.environ.keys()):
        if key.startswith("RECOMMENDER_") or key in ["ORGANIZATION_ID", "SLACK_HOOK_URL"]:
            os.environ.pop(key, None)


@pytest.fixture
def mock_asset():
    """Create a mock GCP asset."""
    asset = Mock()
    asset.project = "projects/123456789"
    asset.name = "//compute.googleapis.com/projects/test-project/zones/us-central1-a/instances/test-instance"
    asset.location = "us-central1-a"
    asset.display_name = "test-instance"
    return asset


@pytest.fixture
def mock_recommendation():
    """Create a mock GCP recommendation."""
    rec = Mock()
    rec.recommender_subtype = "STOP_VM"
    rec.description = "Test recommendation to stop idle VM"

    # Mock cost projection
    rec.primary_impact.cost_projection.cost.units = 100
    rec.primary_impact.cost_projection.cost.nanos = 500000000  # 0.5
    rec.primary_impact.cost_projection.cost.currency_code = "USD"
    rec.primary_impact.cost_projection.duration = "30 days"

    return rec


@pytest.fixture
def mock_recommender_client(monkeypatch):
    """Mock the GCP Recommender API client."""
    mock_client = MagicMock()

    def mock_init(self):
        self.client = mock_client

    monkeypatch.setattr(
        "google.cloud.recommender_v1.RecommenderClient.__init__",
        lambda self: None
    )
    return mock_client


@pytest.fixture
def mock_asset_client(monkeypatch):
    """Mock the GCP Asset API client."""
    mock_client = MagicMock()

    monkeypatch.setattr(
        "google.cloud.asset_v1.AssetServiceClient.__init__",
        lambda self: None
    )
    return mock_client


@pytest.fixture
def mock_context():
    """Create a mock Cloud Function context."""
    context = Mock()
    context.event_id = "test-event-123"
    context.timestamp = "2024-01-01T00:00:00Z"
    return context
