"""Unit tests for base Recommender class."""

import pytest
from unittest.mock import Mock, patch, MagicMock, call
from localpackage.recommender.recommender import Recommender
from localpackage.recommender.models import ProjectInfo, CostImpact


@pytest.mark.unit
class TestRecommender:
    """Tests for the base Recommender class."""

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_init(self, mock_recommender_client, mock_asset_client):
        """Test Recommender initialization."""
        recommender = Recommender(
            recommender_id="test.recommender",
            asset_type="test.asset.Type"
        )

        assert recommender.recommender_id == "test.recommender"
        assert recommender.asset_type == "test.asset.Type"
        assert recommender.organization_id == "123456789"  # From setup_env fixture

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_extract_project_info(self, mock_recommender_client, mock_asset_client, mock_asset):
        """Test _extract_project_info method."""
        recommender = Recommender("test.recommender", "test.asset.Type")
        project_info = recommender._extract_project_info(mock_asset)

        assert isinstance(project_info, ProjectInfo)
        assert project_info.number == "123456789"
        assert project_info.name == "test-project"

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_calculate_cost_impact(self, mock_recommender_client, mock_asset_client, mock_recommendation):
        """Test _calculate_cost_impact method."""
        recommender = Recommender("test.recommender", "test.asset.Type")
        cost_impact = recommender._calculate_cost_impact(mock_recommendation)

        assert isinstance(cost_impact, CostImpact)
        assert cost_impact.units == 100
        assert cost_impact.currency == "USD"
        assert cost_impact.total_cost == 100.5  # 100 + 0.5

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_get_slack_webhook_url_from_env(self, mock_recommender_client, mock_asset_client):
        """Test _get_slack_webhook_url returns URL from environment."""
        recommender = Recommender("test.recommender", "test.asset.Type")
        webhook_url = recommender._get_slack_webhook_url()

        assert webhook_url == "https://hooks.slack.com/test"

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    @patch("localpackage.recommender.recommender.urlopen")
    def test_post_slack_message_success(
        self, mock_urlopen, mock_recommender_client, mock_asset_client
    ):
        """Test _post_slack_message successfully posts to Slack."""
        recommender = Recommender("test.recommender", "test.asset.Type")
        payload = {"text": "Test message"}

        mock_response = MagicMock()
        mock_urlopen.return_value.__enter__.return_value = mock_response

        recommender._post_slack_message(payload)

        assert mock_urlopen.called

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_post_slack_message_no_webhook(
        self, mock_recommender_client, mock_asset_client, monkeypatch
    ):
        """Test _post_slack_message handles missing webhook gracefully."""
        monkeypatch.delenv("SLACK_HOOK_URL", raising=False)

        recommender = Recommender("test.recommender", "test.asset.Type")
        payload = {"text": "Test message"}

        # Should not raise an exception
        recommender._post_slack_message(payload)

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_process_recommendations_filters_by_cost(
        self, mock_recommender_client, mock_asset_client, mock_recommendation, monkeypatch
    ):
        """Test _process_recommendations filters recommendations below threshold."""
        monkeypatch.setenv("MIN_COST_THRESHOLD", "200")  # Higher than mock cost

        recommender = Recommender("test.recommender", "test.asset.Type")

        with patch.object(recommender, "_post_slack_message") as mock_post:
            recommender._process_recommendations("test-project", [mock_recommendation])
            # Should not post since cost (100.5) is below threshold (200)
            assert not mock_post.called

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_search_assets_with_retry(self, mock_recommender_client, mock_asset_client, mock_asset):
        """Test _search_assets handles API calls with retry logic."""
        recommender = Recommender("test.recommender", "test.asset.Type")

        # Mock the search response
        mock_response = Mock()
        mock_response.results = [mock_asset]
        mock_response.next_page_token = ""

        recommender.asset_client.search_all_resources = Mock(return_value=mock_response)

        assets = recommender._search_assets()

        assert len(assets) == 1
        assert assets[0] == mock_asset

    @patch("google.cloud.asset_v1.AssetServiceClient")
    @patch("google.cloud.recommender_v1.RecommenderClient")
    def test_list_recommendations_handles_error(
        self, mock_recommender_client, mock_asset_client
    ):
        """Test _list_recommendations handles API errors gracefully."""
        from google.api_core.exceptions import GoogleAPIError

        recommender = Recommender("test.recommender", "test.asset.Type")
        recommender.recommender_client.list_recommendations = Mock(
            side_effect=GoogleAPIError("Test error")
        )

        # Should return empty list instead of raising
        recommendations = recommender._list_recommendations("123456", "us-central1-a")
        assert recommendations == []
