"""Test suite for GCP Organization Recommender."""
