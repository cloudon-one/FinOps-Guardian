## Testing Guide

### Running Tests

The codebase includes comprehensive unit and integration tests using pytest.

#### Install Dependencies

```bash
cd scripts/cloudfunctions/recommender-checker
pip install -r requirements.txt
```

#### Run All Tests

```bash
# Run all tests with coverage
pytest

# Run only unit tests
pytest -m unit

# Run only integration tests
pytest -m integration

# Run with verbose output
pytest -v

# Run specific test file
pytest tests/test_models.py

# Run specific test function
pytest tests/test_factory.py::TestRecommenderFactory::test_get_enabled_recommenders_none_enabled
```

#### Coverage Reports

```bash
# Generate HTML coverage report
pytest --cov=localpackage --cov-report=html

# View coverage in browser
open htmlcov/index.html

# Generate terminal coverage report
pytest --cov=localpackage --cov-report=term-missing
```

### Test Structure

```
tests/
├── __init__.py
├── conftest.py           # Shared fixtures and configuration
├── test_models.py        # Tests for data models
├── test_factory.py       # Tests for RecommenderFactory
├── test_recommender.py   # Tests for base Recommender class
└── test_main.py          # Tests for Cloud Function entry point
```

### Writing New Tests

When adding new recommenders or features, follow these patterns:

#### Unit Test Example

```python
import pytest
from unittest.mock import Mock, patch

@pytest.mark.unit
def test_my_function():
    # Arrange
    mock_data = Mock()

    # Act
    result = my_function(mock_data)

    # Assert
    assert result is not None
```

#### Integration Test Example

```python
@pytest.mark.integration
def test_full_workflow(monkeypatch):
    # Setup
    monkeypatch.setenv("ORGANIZATION_ID", "123456")

    # Execute full workflow
    result = execute_workflow()

    # Verify
    assert result.success is True
```

### Mocking GCP APIs

The tests use mocks to avoid making real API calls:

```python
@patch("google.cloud.asset_v1.AssetServiceClient")
@patch("google.cloud.recommender_v1.RecommenderClient")
def test_with_mocked_clients(mock_recommender, mock_asset):
    # Your test code here
    pass
```

### Common Fixtures

Available in `conftest.py`:

- `setup_env`: Automatically sets up environment variables
- `mock_asset`: Creates a mock GCP asset
- `mock_recommendation`: Creates a mock recommendation
- `mock_context`: Creates a mock Cloud Function context

### Test Coverage Goals

- **Minimum**: 80% coverage (enforced by pytest.ini)
- **Target**: 90%+ coverage
- **Focus areas**:
  - All public methods
  - Error handling paths
  - Edge cases

### Continuous Integration

To integrate with CI/CD:

```yaml
# Example GitHub Actions workflow
- name: Run tests
  run: |
    cd scripts/cloudfunctions/recommender-checker
    pip install -r requirements.txt
    pytest --cov=localpackage --cov-report=xml

- name: Upload coverage
  uses: codecov/codecov-action@v3
  with:
    file: ./coverage.xml
```

### Troubleshooting

#### ImportError

If you see import errors, ensure you're running tests from the correct directory:

```bash
cd scripts/cloudfunctions/recommender-checker
python -m pytest
```

#### Mock Issues

If mocks aren't working, verify the patch path matches the import location:

```python
# Patch where it's used, not where it's defined
@patch("localpackage.recommender.recommender.RecommenderClient")
```

#### Environment Variables

Tests automatically set up environment variables via `conftest.py`. To override:

```python
def test_with_custom_env(monkeypatch):
    monkeypatch.setenv("ORGANIZATION_ID", "custom-value")
    # Your test
```
